import { useEffect, useRef, useState } from "react";
import "./App.css";

declare global {
  interface Window {
    FaceMesh?: any;
  }
}

type Page = "dashboard" | "upload" | "documents" | "verify" | "audit" | "blockchain" | "enroll" | "eyeScan";

type DocumentItem = {
  filename?: string;
  originalName?: string;
  name?: string;
  size?: number;
  hash?: string;
  uploadedAt?: string;
};

type EyeMode = "enroll" | "retrieve";

const API = "http://localhost:5000/api";

function distance(a: number[], b: number[]) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += (a[i] - b[i]) ** 2;
  return Math.sqrt(sum / a.length);
}

function normalizeFeatures(landmarks: any[]): number[] | null {
  if (!landmarks || landmarks.length < 478) return null;

  // MediaPipe Face Mesh with refineLandmarks=true gives iris landmarks 468-477.
  // Normalize iris points against the corresponding eye box so the template is
  // less dependent on camera distance and overall face position.
  const leftEye = [33, 133, 159, 145, 160, 144];
  const rightEye = [362, 263, 386, 374, 387, 373];
  const leftIris = [468, 469, 470, 471, 472];
  const rightIris = [473, 474, 475, 476, 477];

  const makeEyeVector = (eyeIds: number[], irisIds: number[]) => {
    const eye = eyeIds.map((i) => landmarks[i]);
    const iris = irisIds.map((i) => landmarks[i]);
    const xs = eye.map((p: any) => p.x);
    const ys = eye.map((p: any) => p.y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);
    const w = Math.max(maxX - minX, 1e-6);
    const h = Math.max(maxY - minY, 1e-6);

    const values: number[] = [];
    iris.forEach((p: any) => {
      values.push((p.x - minX) / w);
      values.push((p.y - minY) / h);
    });
    return values;
  };

  const features = [
    ...makeEyeVector(leftEye, leftIris),
    ...makeEyeVector(rightEye, rightIris),
  ];

  // L2 normalize so the backend cosine similarity is meaningful.
  const norm = Math.sqrt(features.reduce((s, v) => s + v * v, 0));
  if (!norm) return null;
  return features.map((v) => v / norm);
}

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("Investigator");
  const [error, setError] = useState("");
  const [page, setPage] = useState<Page>("dashboard");
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [hash, setHash] = useState("");
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [blockchain, setBlockchain] = useState<any[]>([]);

  const [selectedDocument, setSelectedDocument] = useState<DocumentItem | null>(null);
  const [eyeMode, setEyeMode] = useState<EyeMode>("enroll");
  const [scanState, setScanState] = useState("idle");
  const [scanMessage, setScanMessage] = useState("Position your eyes inside the frame");
  const [scanProgress, setScanProgress] = useState(0);
  const [similarity, setSimilarity] = useState<number | null>(null);
  const [threshold, setThreshold] = useState<number | null>(null);
  const [faceReady, setFaceReady] = useState(false);
  const [biometricMessage, setBiometricMessage] = useState("");

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const faceMeshRef = useRef<any>(null);
  const captureTimerRef = useRef<number | null>(null);
  const samplesRef = useRef<number[][]>([]);
  const processingRef = useRef(false);

  const stopCamera = () => {
    if (captureTimerRef.current) {
      window.clearInterval(captureTimerRef.current);
      captureTimerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (faceMeshRef.current?.close) {
      faceMeshRef.current.close();
    }
    faceMeshRef.current = null;
    setFaceReady(false);
    processingRef.current = false;
  };

  useEffect(() => () => stopCamera(), []);

  const handleLogin = async () => {
    setError("");
    if (!username || !password) {
      setError("Please enter username and password.");
      return;
    }
    try {
      const response = await fetch(`${API}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, role }),
      });
      const data = await response.json();
      if (data.success) {
        setLoggedIn(true);
        setPage("dashboard");
        setError("");
      } else setError(data.message || "Login failed.");
    } catch (e) {
      console.error(e);
      setError("Unable to connect to SecureDoc backend.");
    }
  };

  const handleLogout = () => {
    stopCamera();
    setLoggedIn(false);
    setUsername("");
    setPassword("");
    setPage("dashboard");
    setSelectedFile(null);
    setHash("");
  };

  const loadDocuments = async () => {
    try {
      const response = await fetch(`${API}/documents`);
      const data = await response.json();
      if (data.success) {
        setDocuments(data.documents);
        setPage("documents");
      } else alert(data.message);
    } catch (e) {
      console.error(e);
      alert("Failed to load documents.");
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    if (!file) return;
    if (file.type !== "application/pdf") {
      alert("Only PDF files are allowed.");
      return;
    }
    setSelectedFile(file);
    setHash("");
  };

  const handleUpload = async () => {
    if (!selectedFile) return alert("Please select a PDF document first.");
    try {
      const formData = new FormData();
      formData.append("document", selectedFile);
      const response = await fetch(`${API}/upload`, { method: "POST", body: formData });
      const data = await response.json();
      if (data.success) {
        setHash(data.hash);
        setDocuments((prev) => [...prev, data]);
        alert("Document uploaded successfully.");
        setSelectedFile(null);
        const input = document.getElementById("document-upload") as HTMLInputElement | null;
        if (input) input.value = "";
      } else alert(data.message || "Upload failed.");
    } catch (e) {
      console.error(e);
      alert("Upload failed.");
    }
  };

  const handleDelete = async (index: number) => {
    const doc = documents[index];
    const filename = doc?.filename || doc?.originalName || doc?.name;
    if (!filename) return alert("Document filename not found.");
    if (!window.confirm("Are you sure you want to delete this document?")) return;
    try {
      const response = await fetch(`${API}/documents/${encodeURIComponent(filename)}`, { method: "DELETE" });
      const data = await response.json();
      if (data.success) {
        alert("Document deleted successfully.");
        await loadDocuments();
      } else alert(data.message || "Delete failed.");
    } catch (e) {
      console.error(e);
      alert("Failed to delete document.");
    }
  };

  const openAuditLog = async () => {
    try {
      const response = await fetch(`${API}/audit`);
      const data = await response.json();
      if (data.success) {
        setAuditLogs(data.logs);
        setPage("audit");
      } else alert(data.message);
    } catch (e) {
      console.error(e);
      alert("Failed to load audit log.");
    }
  };

  const openBlockchain = async () => {
    try {
      const response = await fetch(`${API}/blockchain`);
      const data = await response.json();
      if (data.success) {
        setBlockchain(data.blockchain);
        setPage("blockchain");
      } else alert(data.message);
    } catch (e) {
      console.error(e);
      alert("Failed to load blockchain.");
    }
  };

  const openEnrollment = () => {
    stopCamera();
    samplesRef.current = [];
    setEyeMode("enroll");
    setSimilarity(null);
    setThreshold(null);
    setScanState("idle");
    setScanProgress(0);
    setScanMessage("Register your eye biometric for this account");
    setBiometricMessage("");
    setPage("enroll");
  };

  const openEyeScan = (doc: DocumentItem) => {
    stopCamera();
    samplesRef.current = [];
    setSelectedDocument(doc);
    setEyeMode("retrieve");
    setSimilarity(null);
    setThreshold(null);
    setScanState("idle");
    setScanProgress(0);
    setScanMessage("Look straight at the camera");
    setBiometricMessage("");
    setPage("eyeScan");
  };

  const setupFaceMesh = async () => {
    if (!window.FaceMesh) {
      throw new Error("Eye vision library did not load. Check your internet connection and refresh the page.");
    }

    const mesh = new window.FaceMesh({
      locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`,
    });
    mesh.setOptions({
      maxNumFaces: 1,
      refineLandmarks: true,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.6,
    });

    mesh.onResults((results: any) => {
      const landmarks = results.multiFaceLandmarks?.[0];
      if (!landmarks) {
        setFaceReady(false);
        setScanMessage("Face/eyes not detected — move closer and face the camera");
        return;
      }
      const features = normalizeFeatures(landmarks);
      if (!features) {
        setFaceReady(false);
        setScanMessage("Iris landmarks not available — keep both eyes visible");
        return;
      }
      setFaceReady(true);
      setScanMessage("Eyes detected — hold still");
      if (!processingRef.current && samplesRef.current.length < 5) {
        samplesRef.current.push(features);
        setScanProgress(Math.min(100, samplesRef.current.length * 20));
      }
    });

    faceMeshRef.current = mesh;
  };

  const averageSamples = (samples: number[][]) => {
    const result = new Array(samples[0].length).fill(0);
    samples.forEach((sample) => sample.forEach((value, i) => (result[i] += value)));
    return result.map((value) => value / samples.length);
  };

  const runBiometric = async () => {
    if (!videoRef.current) return;
    try {
      setScanState("scanning");
      setScanMessage("Starting camera and eye detection...");
      setScanProgress(0);
      samplesRef.current = [];
      await setupFaceMesh();

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      videoRef.current.srcObject = stream;
      await videoRef.current.play();

      captureTimerRef.current = window.setInterval(async () => {
        if (!videoRef.current || !faceMeshRef.current || processingRef.current) return;
        if (samplesRef.current.length >= 5) return;
        processingRef.current = true;
        try {
          await faceMeshRef.current.send({ image: videoRef.current });
        } catch (e) {
          console.error("Face mesh error", e);
        } finally {
          processingRef.current = false;
        }
      }, 300);

      const waitForSamples = window.setInterval(async () => {
        if (samplesRef.current.length < 5) return;
        window.clearInterval(waitForSamples);
        if (captureTimerRef.current) {
          window.clearInterval(captureTimerRef.current);
          captureTimerRef.current = null;
        }
        const template = averageSamples(samplesRef.current);
        setScanState("matching");
        setScanMessage(eyeMode === "enroll" ? "Saving protected biometric template..." : "Comparing with enrolled biometric...");

        try {
          if (eyeMode === "enroll") {
            const response = await fetch(`${API}/biometric/enroll`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ personId: username, template }),
            });
            const data = await response.json();
            if (!data.success) throw new Error(data.message || "Enrollment failed");
            setScanState("success");
            setScanProgress(100);
            setBiometricMessage("Eye biometric enrolled successfully for this account.");
            setScanMessage("Biometric registration complete");
          } else {
            const filename = selectedDocument?.filename || selectedDocument?.originalName || "";
            const response = await fetch(`${API}/biometric/verify`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ personId: username, template, filename }),
            });
            const data = await response.json();
            setSimilarity(typeof data.similarity === "number" ? data.similarity : null);
            setThreshold(typeof data.threshold === "number" ? data.threshold : null);
            if (!data.matched || !data.retrievalToken) {
              setScanState("denied");
              setBiometricMessage(data.message || "Eye biometric did not match.");
              setScanMessage("ACCESS DENIED");
              return;
            }
            setScanState("success");
            setScanProgress(100);
            setBiometricMessage("Identity verified. Secure retrieval token issued.");
            setScanMessage("IDENTITY VERIFIED");
            setTimeout(async () => {
              try {
                const fileResponse = await fetch(`${API}/documents/${encodeURIComponent(filename)}`, {
                  headers: { "x-biometric-token": data.retrievalToken },
                });
                if (!fileResponse.ok) {
                  const body = await fileResponse.text();
                  throw new Error(body || "Secure document retrieval failed");
                }
                const blob = await fileResponse.blob();
                const url = URL.createObjectURL(blob);
                window.open(url, "_blank", "noopener,noreferrer");
                setTimeout(() => URL.revokeObjectURL(url), 60_000);
              } catch (e) {
                console.error(e);
                alert("Biometric matched, but document retrieval failed.");
              }
            }, 700);
          }
        } catch (e: any) {
          console.error(e);
          setScanState("denied");
          setBiometricMessage(e.message || "Biometric operation failed.");
          setScanMessage("BIOMETRIC OPERATION FAILED");
        } finally {
          stopCamera();
        }
      }, 100);

      // Safety timeout for camera/ML initialization.
      window.setTimeout(() => window.clearInterval(waitForSamples), 15_000);
    } catch (e: any) {
      console.error(e);
      stopCamera();
      setScanState("denied");
      setBiometricMessage(e.message || "Camera access failed.");
      setScanMessage("Unable to start eye scan");
    }
  };

  const verifyDocument = async () => {
    if (!selectedFile) return alert("Please select a PDF document.");
    try {
      const formData = new FormData();
      formData.append("document", selectedFile);
      const response = await fetch(`${API}/verify`, { method: "POST", body: formData });
      const data = await response.json();
      alert(data.message || "Verification completed.");
    } catch (e) {
      console.error(e);
      alert("Verification failed.");
    }
  };

  if (!loggedIn) {
    return (
      <div className="login-page">
        <div className="login-card">
          <div className="brand-icon">🔐</div>
          <h1>SecureDoc</h1>
          <p>Secure Digital Document Management System</p>
          <div className="form-group"><label>Username</label><input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Enter username" /></div>
          <div className="form-group"><label>Password</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter password" /></div>
          <div className="form-group"><label>Role</label><select value={role} onChange={(e) => setRole(e.target.value)}><option>Investigator</option><option>Legal Officer</option><option>Administrator</option></select></div>
          {error && <p className="error-message">{error}</p>}
          <button className="login-button" onClick={handleLogin}>🔑 Login</button>
          <p className="login-note">Demo credentials: admin / admin123</p>
        </div>
      </div>
    );
  }

  const renderEyePage = (mode: EyeMode) => (
    <main className="dashboard-content">
      <button className="back-button" onClick={() => { stopCamera(); setPage(mode === "enroll" ? "dashboard" : "documents"); }}>← Back</button>
      <div className="eye-header">
        <div><h1>{mode === "enroll" ? "👁️ Register Eye Biometric" : "👁️ Secure Eye Verification"}</h1><p>{mode === "enroll" ? "Enroll your eye features for secure document access." : `Verify your identity before retrieving ${selectedDocument?.originalName || selectedDocument?.filename || "the document"}.`}</p></div>
        <span className={`security-pill ${scanState === "success" ? "ok" : scanState === "denied" ? "danger" : ""}`}>{scanState === "success" ? "VERIFIED" : scanState === "denied" ? "DENIED" : "BIOMETRIC"}</span>
      </div>
      <div className="eye-card">
        <div className="camera-panel">
          <video ref={videoRef} className="eye-video" playsInline muted />
          <div className="scan-frame"><span /><span /><span /><span /></div>
          <div className="scan-label">{scanMessage}</div>
          <canvas ref={canvasRef} className="hidden-canvas" />
        </div>
        <div className="eye-side">
          <div className="scan-status"><div className={`status-dot ${faceReady ? "active" : ""}`} /><span>{faceReady ? "Eyes detected" : "Waiting for eyes"}</span></div>
          <div className="progress-track"><div className="progress-fill" style={{ width: `${scanProgress}%` }} /></div>
          <p className="progress-text">{scanProgress}% captured</p>
          {similarity !== null && <div className="score-box"><span>Similarity score</span><strong>{similarity.toFixed(4)}</strong>{threshold !== null && <small>Required: {threshold.toFixed(4)}</small>}</div>}
          {biometricMessage && <div className={`result-box ${scanState === "success" ? "result-ok" : "result-danger"}`}>{scanState === "success" ? "✓" : "✕"} {biometricMessage}</div>}
          {scanState === "idle" && <button className="scan-button" onClick={runBiometric}>📷 Start Eye Scan</button>}
          {scanState === "denied" && <button className="scan-button" onClick={runBiometric}>🔄 Scan Again</button>}
          {mode === "enroll" && scanState === "success" && <button className="scan-button" onClick={() => setPage("dashboard")}>✓ Done</button>}
          <div className="biometric-note"><strong>Privacy:</strong> SecureDoc sends a numerical eye-feature template to the backend. It does not upload or store the camera photo.</div>
        </div>
      </div>
    </main>
  );

  return (
    <div className="app-container">
      <header className="dashboard-header">
        <div><h1>🔐 SecureDoc</h1><p>Secure Digital Document Management</p></div>
        <div className="user-info"><span>👤 {role === "Administrator" ? "ADMIN" : role}</span><button className="logout-button" onClick={handleLogout}>Logout</button></div>
      </header>

      {page === "dashboard" && <main className="dashboard-content"><h1>Dashboard</h1><p>Welcome to SecureDoc document management system.</p><div className="dashboard-cards"><div className="dashboard-card"><h2>📄 Documents</h2><p>Secure storage and management of legal documents.</p></div><div className="dashboard-card"><h2>🔒 Security</h2><p>SHA-256 integrity verification protects document authenticity.</p></div><div className="dashboard-card"><h2>👁️ Biometric</h2><p>Eye-feature verification protects document retrieval.</p></div></div><h2>Quick Actions</h2><div className="quick-actions"><div className="action-buttons">{role !== "Legal Officer" && <button onClick={() => setPage("upload")}>📤 Upload Document</button>}<button onClick={loadDocuments}>📁 View Documents</button><button onClick={() => setPage("verify")}>🔍 Verify Document</button><button onClick={openEnrollment}>👁️ Register Eye</button>{(role === "Administrator" || role === "ADMIN") && <><button onClick={openAuditLog}>📋 View Audit Log</button><button onClick={openBlockchain}>⛓️ View Blockchain</button></>}</div></div></main>}

      {page === "upload" && <main className="dashboard-content"><button className="back-button" onClick={() => setPage("dashboard")}>← Back to Dashboard</button><h1>📤 Upload Document</h1><p>Upload a PDF document to SecureDoc.</p><div className="upload-box"><input id="document-upload" type="file" accept="application/pdf" onChange={handleFileChange} />{selectedFile && <div className="selected-file"><h3>Selected Document</h3><p>Name: {selectedFile.name}</p><p>Size: {(selectedFile.size / 1024).toFixed(2)} KB</p></div>}<button className="upload-button" onClick={handleUpload}>📤 Upload PDF</button>{hash && <div className="hash-box"><h3>SHA-256 Document Hash</h3><p>{hash}</p></div>}</div></main>}

      {page === "documents" && <main className="dashboard-content"><button className="back-button" onClick={() => setPage("dashboard")}>← Back to Dashboard</button><h1>📁 Documents</h1><p>Stored SecureDoc documents. Viewing requires eye verification.</p>{documents.length === 0 ? <div className="empty-box"><h2>No documents found</h2><p>Upload a PDF document to get started.</p></div> : <div className="document-list">{documents.map((doc, index) => <div className="document-item" key={doc.filename || index}><div><h3>📄 {doc.originalName || doc.filename}</h3><p>Size: {doc.size ? (doc.size / 1024).toFixed(2) : "0"} KB</p>{doc.hash && <p>SHA-256: {doc.hash}</p>}{doc.uploadedAt && <p>Uploaded: {new Date(doc.uploadedAt).toLocaleString()}</p>}</div><div className="document-actions"><button onClick={() => openEyeScan(doc)}>👁️ Eye Scan & View</button>{(role === "Administrator" || role === "ADMIN") && <button className="delete-button" onClick={() => handleDelete(index)}>🗑️ Delete</button>}</div></div>)}</div>}</main>}

      {page === "verify" && <main className="dashboard-content"><button className="back-button" onClick={() => setPage("dashboard")}>← Back to Dashboard</button><h1>🔍 Verify Document</h1><p>Select a PDF to verify its SHA-256 integrity.</p><div className="upload-box"><input type="file" accept="application/pdf" onChange={handleFileChange} />{selectedFile && <div className="selected-file"><h3>Selected Document</h3><p>{selectedFile.name}</p></div>}<button onClick={verifyDocument}>🔐 Verify Document</button></div></main>}

      {page === "audit" && <main className="dashboard-content"><button className="back-button" onClick={() => setPage("dashboard")}>← Back to Dashboard</button><h1>📋 Audit Log</h1><p>SecureDoc activity records</p>{auditLogs.length === 0 ? <div className="empty-box"><h2>No audit records</h2></div> : <div className="document-list">{auditLogs.map((log, index) => <div className="document-item" key={index}><div><h3>📋 {log.action}</h3><p>Time: {new Date(log.timestamp).toLocaleString()}</p><p>{JSON.stringify(log.details)}</p></div></div>)}</div>}</main>}

      {page === "blockchain" && <main className="dashboard-content"><button className="back-button" onClick={() => setPage("dashboard")}>← Back to Dashboard</button><h1>⛓️ Blockchain Ledger</h1><p>Hash-linked document integrity records</p>{blockchain.length === 0 ? <div className="empty-box"><h2>No blockchain records</h2></div> : <div className="document-list">{blockchain.map((block, index) => <div className="document-item" key={block.blockHash || index}><div><h3>⛓️ Block #{block.index}</h3><p><strong>Document:</strong> {block.filename}</p><p><strong>Document Hash:</strong> {block.documentHash}</p><p><strong>Previous Hash:</strong> {block.previousHash}</p><p><strong>Block Hash:</strong> {block.blockHash}</p><p><strong>Timestamp:</strong> {new Date(block.timestamp).toLocaleString()}</p></div></div>)}</div>}</main>}

      {page === "enroll" && renderEyePage("enroll")}
      {page === "eyeScan" && renderEyePage("retrieve")}
    </div>
  );
}

export default App;
